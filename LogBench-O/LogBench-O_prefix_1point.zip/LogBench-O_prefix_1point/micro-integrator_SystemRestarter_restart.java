public static void restart() {
    log.
    log.info("Halting JVM");
    if (System.getProperty("wrapper.key") != null) {
        // If Carbon was started using wrapper
        WrapperManager.restart();
    } else {
        // If carbon was started using wso2server.sh/.bat
        System.exit(EXIT_CODE);
    }
}