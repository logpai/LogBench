public static <T> void registerService(Bundle bundle, Class<T> serviceClass, Class<? extends T> implClass) {
    try {
        // Load the service class
        if (LOG.isLoggable(Level.WARNING)) {
            LOG.
        }
        // Provide service properties
        Hashtable<String, Object> props = new Hashtable<>();
        props.put(Constants.VERSION_ATTRIBUTE, bundle.getVersion().toString());
        String vendor = bundle.getHeaders().get(Constants.BUNDLE_VENDOR);
        props.put(Constants.SERVICE_VENDOR, (vendor != null ? vendor : "anonymous"));
        // Translate annotated @Priority into a service ranking
        props.put(Constants.SERVICE_RANKING, Integer.valueOf(PriorityServiceComparator.getPriority(implClass)));
        // Register the service factory on behalf of the intercepted bundle
        JDKUtilServiceFactory<T> factory = new JDKUtilServiceFactory<>(implClass);
        BundleContext bundleContext = bundle.getBundleContext();
        bundleContext.registerService(serviceClass.getName(), factory, props);
        if (LOG.isLoggable(Level.FINE)) {
            LOG.fine("Registered service class: " + implClass.getName() + "(" + serviceClass.getName() + ")");
        }
    } catch (Exception e) {
        LOG.log(Level.SEVERE, "Failed to load service: " + implClass.getName(), e);
    }
}