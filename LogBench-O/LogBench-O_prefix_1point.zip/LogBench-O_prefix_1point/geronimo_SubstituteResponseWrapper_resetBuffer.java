@Override
public void resetBuffer() {
    log.
    super.resetBuffer();
    if (substituteRequired()) {
        // If no exception from the wrapped response, let's reset too
        if (stream != null) {
            stream.reset();
        } else if (writer != null) {
            writer.reset();
        }
    }
}