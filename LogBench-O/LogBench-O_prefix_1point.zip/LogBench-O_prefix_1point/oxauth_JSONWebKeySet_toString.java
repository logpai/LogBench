@Override
public String toString() {
    try {
        JSONObject jwks = toJSONObject();
        return toPrettyJson(jwks).replace("\\/", "/");
    } catch (JSONException e) {
        LOG.
        return null;
    } catch (JsonProcessingException e) {
        LOG.error(e.getMessage(), e);
        return null;
    }
}