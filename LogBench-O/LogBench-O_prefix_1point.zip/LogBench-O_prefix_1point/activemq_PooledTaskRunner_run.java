@Override
public void run() {
    runningThread = Thread.currentThread();
    try {
        runTask();
    } finally {
        LOG.
        runningThread = null;
    }
}