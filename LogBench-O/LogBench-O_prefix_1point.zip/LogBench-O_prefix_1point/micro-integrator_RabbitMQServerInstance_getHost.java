/**
 * Returns the host on which docker is running.
 * <p>
 * If the docker instance was started by passing an environment variable to set the host, the given host will be
 * returned. If not, localhost will get returned.
 *
 * @return the ip of the host on which docker is running.
 */
public static String getHost() {
    String host = "localhost";
    try {
        if (DOCKER_HOST.equalsIgnoreCase(TestConfigurationProvider.getAutomationContext().getConfigurationValue(RABBITMQ_HOST_XPATH))) {
            String dockerHost = System.getenv("DOCKER_HOST");
            if ((null != dockerHost) && (!StringUtils.isEmpty(dockerHost))) {
                URI uri;
                try {
                    uri = new URI(dockerHost);
                    host = uri.getHost();
                } catch (URISyntaxException e) {
                    log.
                }
            }
        }
    } catch (XPathExpressionException e) {
        log.warn("Error reading the rabbitmq host in automation.xml. Proceed with default value " + host);
    }
    return host;
}