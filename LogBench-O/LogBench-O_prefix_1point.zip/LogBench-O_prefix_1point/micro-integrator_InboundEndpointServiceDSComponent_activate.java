@Activate
protected void activate(ComponentContext ctx) throws Exception {
    log.
    BundleContext bndCtx = ctx.getBundleContext();
    bndCtx.registerService(InboundEndpointService.class.getName(), new InboundEndpointServiceImpl(), null);
}