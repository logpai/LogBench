public void doFail() {
    log.
}