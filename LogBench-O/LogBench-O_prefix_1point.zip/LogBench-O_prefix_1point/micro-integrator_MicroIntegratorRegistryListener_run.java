public void run() {
    try {
        WatchKey key;
        while ((key = watcher.take()) != null) {
            Path dir = keys.get(key);
            if (dir == null) {
                log.
                continue;
            }
            for (WatchEvent<?> event : key.pollEvents()) {
                @SuppressWarnings("rawtypes")
                WatchEvent.Kind kind = event.kind();
                // Context for directory entry event is the file name of entry
                @SuppressWarnings("unchecked")
                Path changedFileName = ((WatchEvent<Path>) event).context();
                Path changedFilePath = dir.resolve(changedFileName);
                File changedFile = new File(String.valueOf(changedFilePath));
                if (changedFile.isDirectory()) {
                    continue;
                }
                saveFileChanges(changedFile, kind);
            }
            // reset key
            if (!key.reset()) {
                break;
            }
        }
    } catch (InterruptedException e) {
        log.error("Error while listening to registry file changes ", e);
        Thread.currentThread().interrupt();
    }
}