void upload(TelemetryLocalStorage data, TelemetryClientAttributesProvider attributesProvider) {
    try {
        sendPost(createPayload(data, attributesProvider));
    } catch (Throwable catchEmAll) {
        if (InternalDebug.isEnabled()) {
            LOG.
        }
    }
}