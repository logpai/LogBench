@Override
public void exec(int executionCounter) {
    List<String> args = new ArrayList<>();
    args.add(luaScriptState.getSha());
    args.add(String.valueOf(keys.size()));
    args.addAll(keys);
    args.addAll(arguments);
    redisAPI.evalsha(args, event -> {
        if (event.succeeded()) {
            Long unlocked = event.result().toLong();
            promise.complete(unlocked > 0);
        } else {
            String message = event.cause().getMessage();
            if (message != null && message.startsWith("NOSCRIPT")) {
                log.
                log.warn("amount the script got loaded: " + executionCounter);
                if (executionCounter > 10) {
                    promise.fail("amount the script got loaded is higher than 10, we abort");
                } else {
                    luaScriptState.loadLuaScript(new ReleaseLockRedisCommand(luaScriptState, keys, arguments, redisAPI, log, promise), executionCounter);
                }
            } else {
                promise.fail("ReleaseLockRedisCommand request failed with message: " + message);
            }
        }
    });
}