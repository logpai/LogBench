/**
 * Logs details about the request error.
 *
 * @param response
 *            http response
 * @throws IOException
 *             on IO error
 * @throws ParseException
 *             on parse error
 */
public static void handleError(HttpResponse response) throws ParseException, IOException {
    log.
    HttpEntity entity = response.getEntity();
    if (entity != null) {
        log.debug("{}", EntityUtils.toString(entity));
    }
}