@Override
public boolean keepAlive() {
    boolean result = lockFile != null && lockFile.keepAlive();
    LOG.
    return result;
}