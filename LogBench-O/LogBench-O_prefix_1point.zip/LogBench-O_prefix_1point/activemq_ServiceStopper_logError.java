protected void logError(Object service, Throwable e) {
    Logger log = LoggerFactory.getLogger(service.getClass());
    log.
}