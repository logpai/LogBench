public Servant preinvoke(byte[] oid, POA poa, String operation, CookieHolder cookie) {
    // the byte array can be cached in a weak hash map for performance
    Object pk = null;
    try {
        ObjectInputStream is = new ObjectInputStream(new ByteArrayInputStream(oid));
        pk = is.readObject();
        is.close();
        EjbDeployment deployment = getDeployment();
        return new StandardServant(getOrb(), InterfaceType.EJB_OBJECT, deployment, pk);
    } catch (IOException e) {
        // if we can't deserialize, then this object can't exist in this process
        throw (OBJECT_NOT_EXIST) new OBJECT_NOT_EXIST(0, org.omg.CORBA.CompletionStatus.COMPLETED_NO).initCause(e);
    } catch (Exception e) {
        log.
        return null;
    }
}