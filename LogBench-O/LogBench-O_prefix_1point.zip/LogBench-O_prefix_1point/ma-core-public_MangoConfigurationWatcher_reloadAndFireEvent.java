private void reloadAndFireEvent() {
    try {
        mangoProperties.reload();
        if (log.isInfoEnabled()) {
            log.
        }
        eventPublisher.publishEvent(new MangoConfigurationReloadedEvent());
    } catch (Exception e) {
        log.error("Error reloading config file", e);
    }
}