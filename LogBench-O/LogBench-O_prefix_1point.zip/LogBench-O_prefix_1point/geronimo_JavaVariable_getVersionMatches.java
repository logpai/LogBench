public boolean getVersionMatches(String version) {
    version = version.trim();
    boolean result = false;
    if (version.endsWith("*")) {
        version = version.substring(0, version.length() - 1).trim();
        log.
        String tmp = SystemUtils.JAVA_VERSION_TRIMMED;
        log.debug("Requested version: {}", tmp);
        log.debug("JVM version: {}", SystemUtils.JAVA_VERSION_FLOAT);
        result = tmp.startsWith(version);
    } else if (version.endsWith("+")) {
        version = version.substring(0, version.length() - 1).trim();
        log.debug("Checking Java version is greater than: {}", version);
        float tmp = Float.parseFloat(version);
        log.debug("Requested version: {}", tmp);
        log.debug("JVM version: {}", SystemUtils.JAVA_VERSION_FLOAT);
        result = tmp <= SystemUtils.JAVA_VERSION_FLOAT;
    } else {
        log.debug("Checking Java version is equal to: {}", version);
        float tmp = Float.parseFloat(version);
        log.debug("Requested version: {}", tmp);
        log.debug("JVM version: {}", SystemUtils.JAVA_VERSION_FLOAT);
        result = tmp == SystemUtils.JAVA_VERSION_FLOAT;
    }
    return result;
}