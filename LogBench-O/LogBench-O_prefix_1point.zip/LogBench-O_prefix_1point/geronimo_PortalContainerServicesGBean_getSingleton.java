public static PortalContainerServices getSingleton() {
    Kernel kernel = KernelRegistry.getSingleKernel();
    PortalContainerServices portalServices = null;
    try {
        portalServices = (PortalContainerServices) kernel.getGBean(PortalContainerServices.class);
    } catch (Exception e) {
        log.
    }
    return portalServices;
}