public boolean gather(CustomScriptConfiguration script, int step, UmaGatherContext context) {
    try {
        log.
        boolean result = gatherScript(script).gather(step, context);
        log.debug("python 'gather' result: " + result);
        return result;
    } catch (Exception ex) {
        log.error("Failed to execute python 'gather' method, script: " + script.getName() + ", message: " + ex.getMessage(), ex);
        saveScriptError(script.getCustomScript(), ex);
        return false;
    }
}