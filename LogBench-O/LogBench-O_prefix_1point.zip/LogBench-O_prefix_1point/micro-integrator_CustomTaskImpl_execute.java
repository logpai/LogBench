@Override
public void execute() {
    try (DefaultHttpClient httpClient = new DefaultHttpClient()) {
        // prepare the request
        HttpPost postRequest = new HttpPost(url);
        StringEntity input = new StringEntity(message);
        input.setContentType(HttpConstants.MEDIA_TYPE_APPLICATION_JSON);
        postRequest.setEntity(input);
        // Invoke post request and receive response
        HttpResponse response = httpClient.execute(postRequest);
        if (response.getStatusLine().getStatusCode() != 200) {
            LOG.
        }
        // build response string
        String responseAsString = "";
        if (response.getEntity() != null) {
            InputStream in = response.getEntity().getContent();
            int length;
            byte[] tmp = new byte[2048];
            StringBuilder buffer = new StringBuilder();
            while ((length = in.read(tmp)) != -1) {
                buffer.append(new String(tmp, 0, length));
            }
            responseAsString = buffer.toString();
        }
        // extract number of invocations
        JSONObject responseJson = new JSONObject(responseAsString);
        int receivedInvocationCount = responseJson.getInt("invocationCount");
        LOG.info("number of invocations for " + uuid + "=" + receivedInvocationCount);
    } catch (IOException e) {
        LOG.error("Error incrementing the invocation count. Unexpected response received: ", e);
    }
}