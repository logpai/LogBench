private void registerEnvironment(GenericContainer<?> artifactory, ConfigurableEnvironment environment, ArtifactoryProperties properties) {
    Integer mappedPort = artifactory.getMappedPort(properties.generalPort);
    String host = artifactory.getHost();
    LinkedHashMap<String, Object> map = new LinkedHashMap<>();
    map.put("embedded.artifactory.host", host);
    map.put("embedded.artifactory.port", mappedPort);
    map.put("embedded.artifactory.username", properties.getUsername());
    map.put("embedded.artifactory.password", properties.getPassword());
    log.
    MapPropertySource propertySource = new MapPropertySource("embeddedArtifactoryInfo", map);
    environment.getPropertySources().addFirst(propertySource);
}