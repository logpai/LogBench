@Override
protected void setEventActive(long timestamp) {
    this.eventActive = true;
    // Just for the fun of it, make sure that the high limit is active.
    if (limitBreech)
        raiseEvent(limitBreechActiveTime + getDurationMS(), createEventContext());
    else {
        // Perhaps the job wasn't successfully unscheduled. Write a log entry and ignore.
        log.
        eventActive = false;
    }
}