@Test
public void testDurableConsumerEnqueueCountWithZeroPrefetch() throws Exception {
    ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(connectionUri);
    connectionFactory.getPrefetchPolicy().setAll(0);
    Connection connection = connectionFactory.createConnection();
    connection.setClientID(getClass().getName());
    connection.start();
    Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
    Destination destination = session.createTopic("DurableTopic");
    MessageConsumer consumer = session.createDurableSubscriber((Topic) destination, "EnqueueSub");
    BrokerView view = brokerService.getAdminView();
    view.getDurableTopicSubscribers();
    ObjectName subName = view.getDurableTopicSubscribers()[0];
    DurableSubscriptionViewMBean sub = (DurableSubscriptionViewMBean) brokerService.getManagementContext().newProxyInstance(subName, DurableSubscriptionViewMBean.class, true);
    assertEquals(0, sub.getEnqueueCounter());
    LOG.
    // Trigger some pull Timeouts.
    consumer.receive(500);
    consumer.receive(500);
    consumer.receive(500);
    consumer.receive(500);
    consumer.receive(500);
    // Let them all timeout.
    Thread.sleep(600);
    LOG.info("Enqueue counter for sub after pull requests: " + sub.getEnqueueCounter());
    assertEquals(0, sub.getEnqueueCounter());
    consumer.close();
    session.close();
    connection.close();
}