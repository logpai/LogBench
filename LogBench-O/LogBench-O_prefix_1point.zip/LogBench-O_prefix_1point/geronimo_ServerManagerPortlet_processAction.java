public void processAction(ActionRequest actionRequest, ActionResponse actionResponse) throws PortletException, IOException {
    Bundle framework = ((BundleReference) getClass().getClassLoader()).getBundle().getBundleContext().getBundle(0);
    if (actionRequest.getParameter("reboot") != null) {
        log.
        try {
            framework.update();
        } catch (BundleException e) {
            log.info("Problem rebooting", e);
        }
        // new Thread() {
        // public void run() {
        // try {
        // Thread.sleep(2000);
        // } catch (InterruptedException e) {
        // }
        // kernel.shutdown();
        // Daemon.main(new String[0]);
        // }
        // }.start();
    } else if (actionRequest.getParameter("shutdown") != null) {
        log.info("Shutting down by user request: " + actionRequest.getUserPrincipal().getName());
        // kernel.shutdown();
        // System.exit(0);
        try {
            framework.stop();
        } catch (BundleException e) {
            log.info("Problem rebooting", e);
        }
    }
}