@Test(timeout = 60000)
public void testMBeanPresenceOnRestart() throws Exception {
    createBroker(true);
    sendMessages();
    verifyPresenceOfQueueMbean();
    LOG.
    restartBroker();
    verifyPresenceOfQueueMbean();
}