@Override
public RecordWriter<IEtlKey, CamusWrapper> getDataRecordWriter(TaskAttemptContext context, String fileName, CamusWrapper camusWrapper, FileOutputCommitter committer) throws IOException, InterruptedException {
    Configuration conf = context.getConfiguration();
    // If recordDelimiter hasn't been initialized, do so now
    if (recordDelimiter == null) {
        recordDelimiter = conf.get(ETL_OUTPUT_RECORD_DELIMITER, DEFAULT_RECORD_DELIMITER);
    }
    CompressionCodec compressionCodec = null;
    CompressionType compressionType = CompressionType.NONE;
    // Determine compression type (BLOCK or RECORD) and compression codec to use.
    if (SequenceFileOutputFormat.getCompressOutput(context)) {
        compressionType = SequenceFileOutputFormat.getOutputCompressionType(context);
        Class<?> codecClass = SequenceFileOutputFormat.getOutputCompressorClass(context, DefaultCodec.class);
        // Instantiate the CompressionCodec Class
        compressionCodec = (CompressionCodec) ReflectionUtils.newInstance(codecClass, conf);
    }
    // Get the filename for this RecordWriter.
    Path path = new Path(committer.getWorkPath(), EtlMultiOutputFormat.getUniqueFile(context, fileName, getFilenameExtension()));
    log.
    final SequenceFile.Writer writer = SequenceFile.createWriter(path.getFileSystem(conf), conf, path, LongWritable.class, Text.class, compressionType, compressionCodec, context);
    // Return a new anonymous RecordWriter that uses the
    // SequenceFile.Writer to write data to HDFS
    return new RecordWriter<IEtlKey, CamusWrapper>() {

        @Override
        public void write(IEtlKey key, CamusWrapper data) throws IOException, InterruptedException {
            String record = (String) data.getRecord() + recordDelimiter;
            // Use the timestamp from the EtlKey as the key for this record.
            // TODO: Is there a better key to use here?
            writer.append(new LongWritable(key.getTime()), new Text(record));
        }

        @Override
        public void close(TaskAttemptContext context) throws IOException, InterruptedException {
            writer.close();
        }
    };
}