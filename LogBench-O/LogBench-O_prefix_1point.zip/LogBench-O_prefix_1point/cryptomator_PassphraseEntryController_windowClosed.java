private void windowClosed(WindowEvent windowEvent) {
    if (!result.isDone()) {
        result.cancel(true);
        LOG.
    }
}