@Test(groups = { "wso2.esb" }, description = "testing local transport scenario")
public void testLocalTransportScenario() throws Exception {
    OMElement response = axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("LocalTransportProxy"), null, "WSO2");
    String symbol = response.getFirstElement().getFirstChildWithName(new QName("http://services.samples/xsd", "symbol")).getText();
    log.
    assertEquals(symbol, "WSO2", "Symbol mismatched.");
}