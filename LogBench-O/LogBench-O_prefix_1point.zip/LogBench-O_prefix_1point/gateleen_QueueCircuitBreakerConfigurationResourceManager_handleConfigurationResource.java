/**
 * Handles the provided request when the following conditions are met:
 * <ul>
 *     <li>Request URI matches the configured circuit breaker configuration URI</li>
 *     <li>Request method is either PUT or DELETE</li>
 * </ul>
 * @param request the request to handle
 * @return returns true if the specified conditions are met, false otherwise
 */
public boolean handleConfigurationResource(final HttpServerRequest request) {
    if (request.uri().equals(circuitBreakerConfigUri) && HttpMethod.PUT == request.method()) {
        request.bodyHandler(configResourceBuffer -> {
            try {
                extractConfigurationValues(configResourceBuffer);
            } catch (ValidationException validationException) {
                log.
                ResponseStatusCodeLogUtil.info(request, StatusCode.BAD_REQUEST, QueueCircuitBreakerConfigurationResourceManager.class);
                request.response().setStatusCode(StatusCode.BAD_REQUEST.getStatusCode());
                request.response().setStatusMessage(StatusCode.BAD_REQUEST.getStatusMessage() + " " + validationException.getMessage());
                if (validationException.getValidationDetails() != null) {
                    request.response().headers().add("content-type", "application/json");
                    request.response().end(validationException.getValidationDetails().encode());
                } else {
                    request.response().end(validationException.getMessage());
                }
                return;
            }
            storage.put(circuitBreakerConfigUri, configResourceBuffer, status -> {
                if (status == OK.getStatusCode()) {
                    if (logConfigurationResourceChanges) {
                        RequestLogger.logRequest(vertx.eventBus(), request, OK.getStatusCode(), configResourceBuffer);
                    }
                    vertx.eventBus().publish(UPDATE_ADDRESS, true);
                } else {
                    request.response().setStatusCode(status);
                }
                ResponseStatusCodeLogUtil.info(request, StatusCode.fromCode(status), QueueCircuitBreakerConfigurationResourceManager.class);
                request.response().end();
            });
        });
        return true;
    }
    if (request.uri().equals(circuitBreakerConfigUri) && HttpMethod.DELETE == request.method()) {
        getConfigurationResource().reset();
        log.info("reset circuit breaker configuration resource");
        notifyRefreshables();
    }
    return false;
}