private static String extractAndValidateToken(ClassicHttpRequest request) throws IOException, ParseException {
    var requestEntityString = EntityUtils.toString(request.getEntity(), "UTF-8");
    String token = null;
    try {
        token = new Gson().fromJson(requestEntityString, TokenPayload.class).token;
    } catch (Exception e) {
        // will be converted to HTTP response later
        LOG.
    }
    return token;
}