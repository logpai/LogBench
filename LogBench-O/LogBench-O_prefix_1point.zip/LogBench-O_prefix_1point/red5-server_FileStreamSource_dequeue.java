/**
 * Get tag from queue and convert to message
 *
 * @return RTMP event
 */
public IRTMPEvent dequeue() {
    if (reader.hasMoreTags()) {
        ITag tag = reader.readTag();
        IRTMPEvent msg;
        switch(tag.getDataType()) {
            case TYPE_AUDIO_DATA:
                msg = new AudioData(tag.getBody());
                break;
            case TYPE_VIDEO_DATA:
                msg = new VideoData(tag.getBody());
                break;
            case TYPE_INVOKE:
                msg = new Invoke(tag.getBody());
                break;
            case TYPE_NOTIFY:
                msg = new Notify(tag.getBody());
                break;
            default:
                log.
                msg = new Unknown(tag.getDataType(), tag.getBody());
                break;
        }
        msg.setTimestamp(tag.getTimestamp());
        // msg.setSealed(true);
        return msg;
    }
    return null;
}