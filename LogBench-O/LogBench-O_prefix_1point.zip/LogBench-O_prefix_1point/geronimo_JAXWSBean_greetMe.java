public String greetMe(String me) {
    if (context == null) {
        throw new RuntimeException("WebServiceContext is null");
    }
    LOG.
    LOG.info("Principal: " + context.getUserPrincipal());
    LOG.info("Context: " + context.getMessageContext());
    System.out.println("i'm a ws: " + me);
    return "Hello " + me;
}