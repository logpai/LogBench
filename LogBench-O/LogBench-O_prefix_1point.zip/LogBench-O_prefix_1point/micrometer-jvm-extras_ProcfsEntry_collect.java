/* default */
final void collect() {
    if (lastHandle != -1 && lastHandle + CACHE_DURATION_MS > currentTime()) {
        return;
    }
    synchronized (lock) {
        if (lastHandle != -1 && lastHandle + CACHE_DURATION_MS > currentTime()) {
            return;
        }
        try {
            final Map<ValueKey, Double> handledValues = new HashMap<>();
            reader.read(line -> handle(handledValues, line));
            values.clear();
            values.putAll(handledValues);
            lastHandle = currentTime();
        } catch (IOException e) {
            values.clear();
            log.
        }
    }
}