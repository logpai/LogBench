@BeforeClass(alwaysRun = true)
public void serviceDeployment() throws Exception {
    super.init();
    serviceEndPoint = getServiceUrlHttp(serviceName);
    String resourceFileLocation = getResourceLocation();
    deployService(serviceName, new DataHandler(new URL("file:///" + resourceFileLocation + File.separator + "dbs" + File.separator + "sparql" + File.separator + "SPARQLDataService.dbs")));
    log.
}