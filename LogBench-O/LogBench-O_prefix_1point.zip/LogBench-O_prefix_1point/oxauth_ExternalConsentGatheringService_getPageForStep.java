public String getPageForStep(CustomScriptConfiguration script, int step, ConsentGatheringContext context) {
    try {
        log.
        String result = consentScript(script).getPageForStep(step, context);
        log.trace("python 'getPageForStep' result: " + result);
        return result;
    } catch (Exception ex) {
        log.error("Failed to execute python 'getPageForStep' method, script: " + script.getName() + ", message: " + ex.getMessage(), ex);
        saveScriptError(script.getCustomScript(), ex);
        return "";
    }
}