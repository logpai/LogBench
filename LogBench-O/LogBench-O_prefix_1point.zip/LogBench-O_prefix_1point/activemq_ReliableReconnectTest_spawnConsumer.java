protected void spawnConsumer() {
    Thread thread = new Thread(new Runnable() {

        public void run() {
            try {
                Connection consumerConnection = createConsumerConnection();
                MessageConsumer consumer = createConsumer(consumerConnection);
                // consume some messages
                for (int i = 0; i < firstBatch; i++) {
                    Message msg = consumer.receive(RECEIVE_TIMEOUT);
                    if (msg != null) {
                        // log.
                        messagesReceived.incrementAndGet();
                    }
                }
                synchronized (closeBroker) {
                    closeBroker.set(true);
                    closeBroker.notify();
                }
                Thread.sleep(2000);
                for (int i = firstBatch; i < MESSAGE_COUNT; i++) {
                    Message msg = consumer.receive(RECEIVE_TIMEOUT);
                    // log.info("GOT: " + msg);
                    if (msg != null) {
                        messagesReceived.incrementAndGet();
                    }
                }
                consumerConnection.close();
                synchronized (messagesReceived) {
                    messagesReceived.notify();
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    });
    thread.start();
}