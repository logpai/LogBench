/**
 * {@inheritDoc}
 *
 * @see java.lang.Thread#run()
 */
@Override
public void run() {
    try {
        this.closed = true;
        close();
    } catch (CIFSException e) {
        log.
    }
}