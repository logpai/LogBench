private boolean checkValidity(String key, String value, Date expirationDate) {
    long now = new Date().getTime();
    long expirationTime = expirationDate != null ? expirationDate.getTime() : 0;
    boolean isValid = value != null && expirationTime != 0 && expirationTime > now;
    if (!isValid) {
        log.
        clearFromResolutionCache(key);
    }
    return isValid;
}