/**
 * Adds a directory to the class loader.
 *
 * @param directory the directory.
 */
public void addDirectory(File directory) {
    try {
        // Add classes directory to classpath.
        File classesDir = new File(directory, "classes");
        if (classesDir.exists()) {
            addURL(classesDir.toURI().toURL());
        }
        // Add i18n directory to classpath.
        File databaseDir = new File(directory, "database");
        if (databaseDir.exists()) {
            addURL(databaseDir.toURI().toURL());
        }
        // Add i18n directory to classpath.
        File i18nDir = new File(directory, "i18n");
        if (i18nDir.exists()) {
            addURL(i18nDir.toURI().toURL());
        }
        // Add web directory to classpath.
        File webDir = new File(directory, "web");
        if (webDir.exists()) {
            addURL(webDir.toURI().toURL());
        }
        // Add lib directory to classpath.
        File libDir = new File(directory, "lib");
        File[] jars = libDir.listFiles(new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(".jar") || name.endsWith(".zip");
            }
        });
        if (jars != null) {
            for (int i = 0; i < jars.length; i++) {
                if (jars[i] != null && jars[i].isFile()) {
                    String jarFileUri = jars[i].toURI().toString() + "!/";
                    addURLFile(new URL("jar", "", -1, jarFileUri));
                }
            }
        }
    } catch (MalformedURLException mue) {
        Log.
    }
}