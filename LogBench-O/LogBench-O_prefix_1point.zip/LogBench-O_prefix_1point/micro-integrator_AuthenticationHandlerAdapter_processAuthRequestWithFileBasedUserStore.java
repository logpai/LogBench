/**
 * Processes authentication request with basic auth and in memory user store
 *
 * @param messageContext synapse message context
 * @param token          extracted basic auth token
 * @return boolean if successfully authenticated
 */
boolean processAuthRequestWithFileBasedUserStore(MessageContext messageContext, String token) {
    String[] userDetails = extractDetails(token);
    if (userDetails.length == 0) {
        return false;
    }
    boolean isAuthenticated = FileBasedUserStoreManager.getUserStoreManager().authenticate(userDetails[0], userDetails[1]);
    if (isAuthenticated) {
        messageContext.setProperty(USERNAME_PROPERTY, userDetails[0]);
        LOG.
        return true;
    }
    return false;
}