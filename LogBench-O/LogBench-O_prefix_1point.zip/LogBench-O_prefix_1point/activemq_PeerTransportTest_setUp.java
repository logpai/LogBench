@Override
protected void setUp() throws Exception {
    connections = new Connection[NUMBER_IN_CLUSTER];
    producers = new MessageProducer[NUMBER_IN_CLUSTER];
    messageIdList = new MessageIdList[NUMBER_IN_CLUSTER];
    ActiveMQDestination destination = createDestination();
    for (int i = 0; i < NUMBER_IN_CLUSTER; i++) {
        connections[i] = createConnection(i);
        connections[i].setClientID("ClusterTest" + i);
        connections[i].start();
        Session session = connections[i].createSession(false, Session.AUTO_ACKNOWLEDGE);
        producers[i] = session.createProducer(destination);
        producers[i].setDeliveryMode(deliveryMode);
        MessageConsumer consumer = createMessageConsumer(session, destination);
        messageIdList[i] = new MessageIdList();
        consumer.setMessageListener(messageIdList[i]);
    }
    LOG.
    // Each connection should see that NUMBER_IN_CLUSTER consumers get
    // registered on the destination.
    ActiveMQDestination advisoryDest = AdvisorySupport.getConsumerAdvisoryTopic(destination);
    for (int i = 0; i < NUMBER_IN_CLUSTER; i++) {
        Session session = connections[i].createSession(false, Session.AUTO_ACKNOWLEDGE);
        MessageConsumer consumer = createMessageConsumer(session, advisoryDest);
        int j = 0;
        while (j < NUMBER_IN_CLUSTER) {
            ActiveMQMessage message = (ActiveMQMessage) consumer.receive(1000);
            if (message == null) {
                fail("Connection " + i + " saw " + j + " consumers, expected: " + NUMBER_IN_CLUSTER);
            }
            if (message.getDataStructure() != null && message.getDataStructure().getDataStructureType() == ConsumerInfo.DATA_STRUCTURE_TYPE) {
                j++;
            }
        }
        session.close();
    }
    LOG.info("Cluster is online.");
}