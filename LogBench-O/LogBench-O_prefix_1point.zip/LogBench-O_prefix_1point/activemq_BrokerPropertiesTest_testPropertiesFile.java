public void testPropertiesFile() throws Exception {
    BrokerService broker = BrokerFactory.createBroker("properties:org/apache/activemq/config/broker.properties");
    LOG.
    assertNotNull(broker);
    assertEquals("isUseJmx()", false, broker.isUseJmx());
    assertEquals("isPersistent()", false, broker.isPersistent());
    assertEquals("getBrokerName()", "Cheese", broker.getBrokerName());
    broker.stop();
}