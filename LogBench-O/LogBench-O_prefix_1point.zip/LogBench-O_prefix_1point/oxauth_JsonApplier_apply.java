public void apply(JSONObject source, Object target, PropertyDefinition property) {
    try {
        if (!source.has(property.getJsonName())) {
            return;
        }
        if (!isAllowed(source, target, property, target.getClass())) {
            return;
        }
        Field field = target.getClass().getDeclaredField(property.getJavaTargetPropertyName());
        field.setAccessible(true);
        Object valueToSet = null;
        if (String.class.isAssignableFrom(property.getJavaType())) {
            valueToSet = source.optString(property.getJsonName());
        }
        if (Collection.class.isAssignableFrom(property.getJavaType())) {
            final JSONArray jsonArray = source.getJSONArray(property.getJsonName());
            valueToSet = jsonArray.toList();
        }
        field.set(target, valueToSet);
    } catch (Exception e) {
        log.
    }
}