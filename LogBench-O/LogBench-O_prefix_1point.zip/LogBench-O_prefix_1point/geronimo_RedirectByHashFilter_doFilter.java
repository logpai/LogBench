public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
    // Generate hash for pure portlets page but not the index page.
    if (request instanceof HttpServletRequest && request.getParameter(NOXSS_SHOW_TREE) == null) {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String currentRequestURI = httpServletRequest.getServletPath() + httpServletRequest.getPathInfo();
        String hash;
        if (redirectURLToHash.get(currentRequestURI) == null) {
            hash = Long.toString(random.nextLong());
            // ensure the key is unique
            while (hashToRedirectURL.keySet().contains(hash)) {
                hash = Long.toString(random.nextLong());
            }
            hashToRedirectURL.put(hash, currentRequestURI);
            redirectURLToHash.put(currentRequestURI, hash);
        } else {
            hash = redirectURLToHash.get(currentRequestURI);
        }
        log.
        // this attribute will be used to add hash to index page.
        request.setAttribute(HASH_OF_CURRENT_PORTAL_PAGE, hash);
    }
    String hashOfPageToRedirect = request.getParameter(NOXSS_HASH_OF_PAGE_TO_REDIRECT);
    // Redirect index page url that contain noxssPage=xxxxxx to the real destination.
    if (hashOfPageToRedirect != null && request.getParameter(NOXSS_SHOW_TREE) != null) {
        String pageToRedirect = hashToRedirectURL.get(hashOfPageToRedirect) + "?" + NOXSS_SHOW_TREE + "=true";
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        // log.info("Redirecting to:" + pageToRedirect+" according to hash:"+hashOfPageToRedirect);
        // pageToRedirect=pageToRedirect.substring("/console".length());
        log.debug("Redirecting to:" + pageToRedirect + " according to hash:" + hashOfPageToRedirect);
        // request.getParameterMap().remove(NOXSS_HASH_OF_PAGE_TO_REDIRECT);
        request.getRequestDispatcher(pageToRedirect).forward(request, response);
        return;
        // httpServletResponse.sendRedirect(pageToRedirect);
    } else {
        log.debug("no redirect for:" + ((HttpServletRequest) request).getRequestURL());
        filterChain.doFilter(request, response);
    }
}