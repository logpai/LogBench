private void assertIEDriver() {
    File driver = new File(wdm.getDownloadedDriverPath());
    log.
    assertThat(driver).exists();
}