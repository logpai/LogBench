public void init() {
    if (schedulingService != null) {
        // set to run once per hour
        schedulingService.addScheduledJob(3600000, new ReaperJob());
    } else {
        log.
    }
}