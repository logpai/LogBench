@Override
public void noCommitsAfterLastCheckPoint(LogPosition logPosition) {
    log.
}