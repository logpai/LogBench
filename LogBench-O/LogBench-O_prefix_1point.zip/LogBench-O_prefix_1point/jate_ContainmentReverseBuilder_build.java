@Override
public AbstractFeature build() throws JATEException {
    Map<String, Set<String>> term2ParentMap = fContainment.getTerm2ParentsMap();
    Map<String, Set<String>> reverseMap = new HashMap<>();
    LOG.
    int count = 0;
    for (Map.Entry<String, Set<String>> e : term2ParentMap.entrySet()) {
        String term = e.getKey();
        Set<String> parents = e.getValue();
        count++;
        if (count % 5000 == 0)
            LOG.info("\tprocessed=" + count);
        for (String p : parents) {
            Set<String> children = reverseMap.get(p);
            if (children == null)
                children = new HashSet<>();
            children.add(term);
            reverseMap.put(p, children);
        }
    }
    Containment rc = new Containment();
    rc.getTerm2ParentsMap().putAll(reverseMap);
    return rc;
}