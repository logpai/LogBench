public void startServers(TestServerManager... serverManagers) throws AutomationFrameworkException {
    int noOfServers = serverManagers.length;
    for (int index = 0; index < noOfServers; ++index) {
        log.
        TestServerManager testServerManager = serverManagers[index];
        try {
            String carbonHome = testServerManager.startServer();
            servers.put(carbonHome, testServerManager);
            serverHomes.add(carbonHome);
        } catch (Exception ex) {
            throw new AutomationFrameworkException(ex);
        }
    }
}