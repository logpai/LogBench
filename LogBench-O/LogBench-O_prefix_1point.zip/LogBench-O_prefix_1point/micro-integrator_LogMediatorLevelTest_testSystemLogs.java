@Test(groups = "wso2.esb", description = "Tests System Logs")
public void testSystemLogs() throws Exception {
    CarbonLogReader carbonLogReader = new CarbonLogReader();
    carbonLogReader.start();
    OMElement response = axis2Client.sendSimpleStockQuoteRequest(getProxyServiceURLHttp("logMediatorLevelTestProxy"), null, "WSO2");
    Assert.assertTrue(response.toString().contains("WSO2"));
    log.
    boolean logFound = carbonLogReader.checkForLog("*****TEST CUSTOM LOGGING MESSAGE TO SYSTEM LOGS TEST*****", DEFAULT_TIMEOUT);
    Assert.assertTrue(logFound, "System Log not found. LogViewer Admin service not working properly");
    carbonLogReader.stop();
}