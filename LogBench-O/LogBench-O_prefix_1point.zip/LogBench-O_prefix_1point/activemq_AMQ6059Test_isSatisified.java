@Override
public boolean isSatisified() throws Exception {
    LOG.
    return queueViewMBean.getEnqueueCount() == 1;
}