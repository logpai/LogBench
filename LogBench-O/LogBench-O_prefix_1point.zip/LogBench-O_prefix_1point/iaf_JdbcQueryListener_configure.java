@Override
public void configure() throws ConfigurationException {
    if (StringUtils.isEmpty(getSelectQuery())) {
        throw new ConfigurationException("selectQuery must be specified");
    }
    if (!knownProcessStates().contains(ProcessState.DONE)) {
        throw new ConfigurationException("updateStatusToProcessedQuery must be specified");
    }
    if (StringUtils.isEmpty(getKeyField())) {
        throw new ConfigurationException("keyField must be specified");
    }
    if (!knownProcessStates().contains(ProcessState.ERROR)) {
        log.
        setUpdateStatusQuery(ProcessState.ERROR, getUpdateStatusQuery(ProcessState.DONE));
    }
    super.configure();
    if (!knownProcessStates().contains(ProcessState.INPROCESS) && !getDbmsSupport().hasSkipLockedFunctionality()) {
        ConfigurationWarnings.add(this, log, "Database [" + getDbmsSupport().getDbmsName() + "] needs updateStatusToInProcessQuery to run in multiple threads");
    }
}