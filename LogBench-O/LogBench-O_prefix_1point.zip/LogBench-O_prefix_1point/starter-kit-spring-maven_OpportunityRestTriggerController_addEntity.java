/**
 * Called when opportunity is added.
 *
 * @param body
 *
 * @return the json parsed form response message
 */
@RequestMapping(value = { "add" }, method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_UTF8_VALUE })
@ResponseBody
public RestTriggerResponse addEntity(@RequestBody String body) {
    log.
    Map<String, Object> valuesChanges = (Map<String, Object>) convertToMap(body).get("data");
    RestTriggerRequest<Opportunity> restTriggerRequest = convertToObject(body);
    Integer entityID = restTriggerRequest.getMeta().getEntityId();
    Integer updatingUserID = restTriggerRequest.getMeta().getUserId();
    OpportunityRestTriggerTraverser traverser = new OpportunityRestTriggerTraverser(entityID, valuesChanges, updatingUserID, false, getRelatedEntityFields());
    return handleRequest(traverser, valuesChanges);
}