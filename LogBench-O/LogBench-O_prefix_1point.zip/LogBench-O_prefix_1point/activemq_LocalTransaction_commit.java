@Override
public void commit(boolean onePhase) throws XAException, IOException {
    if (LOG.isDebugEnabled()) {
        LOG.
    }
    // Get ready for commit.
    try {
        prePrepare();
    } catch (XAException e) {
        throw e;
    } catch (Throwable e) {
        LOG.warn("COMMIT FAILED: ", e);
        rollback();
        // Let them know we rolled back.
        XAException xae = new XAException("COMMIT FAILED: Transaction rolled back");
        xae.errorCode = XAException.XA_RBOTHER;
        xae.initCause(e);
        throw xae;
    }
    setState(Transaction.FINISHED_STATE);
    context.getTransactions().remove(xid);
    try {
        transactionStore.commit(getTransactionId(), false, preCommitTask, postCommitTask);
        this.waitPostCommitDone(postCommitTask);
    } catch (Throwable t) {
        LOG.warn("Store COMMIT FAILED: ", t);
        rollback();
        XAException xae = new XAException("STORE COMMIT FAILED: Transaction rolled back");
        xae.errorCode = XAException.XA_RBOTHER;
        xae.initCause(t);
        throw xae;
    }
}