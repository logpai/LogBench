@GetMapping(value = "/listen")
public SseEmitter listenOperations() throws IOException, EventStoreException {
    SseEmitter sseEmitter = new SseEmitter(Long.MAX_VALUE);
    operationsBroadcaster.registerEmitter(sseEmitter);
    sseEmitter.onCompletion(() -> {
        log.
        operationsBroadcaster.deregisterEmitter(sseEmitter);
    });
    sseEmitter.onTimeout(() -> {
        log.info("SseEmitter is timed out");
        operationsBroadcaster.deregisterEmitter(sseEmitter);
    });
    sseEmitter.onError(ex -> {
        log.info("SseEmitter got error:", ex);
        operationsBroadcaster.deregisterEmitter(sseEmitter);
    });
    log.info("Returning SSE Emitter");
    return sseEmitter;
}