@Override
public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
    log.
    ctx.close();
}