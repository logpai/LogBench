@Test
public void testFLVReaderFileWithPreProcessInfo() {
    log.
    // Path path = Paths.get("target/test-classes/fixtures/flv1_nelly.flv");
    Path path = Paths.get("target/test-classes/fixtures/webrtctestrecord.flv");
    try {
        File file = path.toFile();
        log.info("Reading: {}", file.getName());
        FLVReader reader = new FLVReader(file, true);
        // KeyFrameMeta meta = reader.analyzeKeyFrames();
        // log.debug("Meta: {}", meta);
        ITag tag = null;
        for (int t = 0; t < 6; t++) {
            tag = reader.readTag();
            log.debug("Tag: {}", tag);
            assertNotNull(tag.getBody());
        }
        reader.close();
        log.info("Finished reading: {}\n", file.getName());
    } catch (IOException e) {
        e.printStackTrace();
    }
}