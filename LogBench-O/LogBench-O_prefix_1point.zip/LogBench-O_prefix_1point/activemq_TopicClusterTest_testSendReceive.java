/**
 * @throws Exception
 */
public void testSendReceive() throws Exception {
    for (int i = 0; i < MESSAGE_COUNT; i++) {
        TextMessage textMessage = new ActiveMQTextMessage();
        textMessage.setText("MSG-NO:" + i);
        for (int x = 0; x < producers.length; x++) {
            producers[x].send(textMessage);
        }
    }
    synchronized (receivedMessageCount) {
        if (receivedMessageCount.get() < expectedReceiveCount()) {
            receivedMessageCount.wait(20000);
        }
    }
    // sleep a little - to check we don't get too many messages
    Thread.sleep(2000);
    LOG.
    assertEquals("Expected message count not correct", expectedReceiveCount(), receivedMessageCount.get());
}