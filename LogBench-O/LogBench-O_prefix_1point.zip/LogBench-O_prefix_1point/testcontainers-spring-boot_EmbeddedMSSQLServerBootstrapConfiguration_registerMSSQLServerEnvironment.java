private void registerMSSQLServerEnvironment(MSSQLServerContainer<?> mssqlServerContainer, ConfigurableEnvironment environment, MSSQLServerProperties properties) {
    Integer mappedPort = mssqlServerContainer.getMappedPort(MSSQLServerContainer.MS_SQL_SERVER_PORT);
    String host = mssqlServerContainer.getHost();
    LinkedHashMap<String, Object> map = new LinkedHashMap<>();
    map.put("embedded.mssqlserver.port", mappedPort);
    map.put("embedded.mssqlserver.host", host);
    // Database and user cannot be chosen when starting the MSSQL image
    map.put("embedded.mssqlserver.database", "master");
    map.put("embedded.mssqlserver.user", "sa");
    map.put("embedded.mssqlserver.password", properties.getPassword());
    String jdbcURL = "jdbc:sqlserver://{}:{};databaseName={};trustServerCertificate=true";
    log.
    MapPropertySource propertySource = new MapPropertySource("embeddedMSSQLServerInfo", map);
    environment.getPropertySources().addFirst(propertySource);
}