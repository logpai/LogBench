private void toggleNodeOrientation(@SuppressWarnings("unused") ObservableValue<? extends Toggle> observable, @SuppressWarnings("unused") Toggle oldValue, Toggle newValue) {
    if (nodeOrientationLtr.equals(newValue)) {
        settings.userInterfaceOrientation().set(NodeOrientation.LEFT_TO_RIGHT);
    } else if (nodeOrientationRtl.equals(newValue)) {
        settings.userInterfaceOrientation().set(NodeOrientation.RIGHT_TO_LEFT);
    } else {
        LOG.
    }
}