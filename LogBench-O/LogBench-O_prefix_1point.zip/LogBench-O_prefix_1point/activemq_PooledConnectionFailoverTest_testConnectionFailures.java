@Test
public void testConnectionFailures() throws Exception {
    final CountDownLatch failed = new CountDownLatch(1);
    Connection connection = pooledConnFact.createConnection();
    LOG.
    connection.setExceptionListener(new ExceptionListener() {

        @Override
        public void onException(JMSException exception) {
            LOG.info("Pooled Connection failed");
            failed.countDown();
        }
    });
    Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
    Queue queue = session.createQueue(getTestName());
    MessageProducer producer = session.createProducer(queue);
    brokerService.stop();
    assertTrue(failed.await(15, TimeUnit.SECONDS));
    createBroker();
    try {
        producer.send(session.createMessage());
        fail("Should be disconnected");
    } catch (JMSException ex) {
        LOG.info("Producer failed as expected: {}", ex.getMessage());
    }
    Connection connection2 = pooledConnFact.createConnection();
    assertNotSame(connection, connection2);
    LOG.info("Fetched new connection from the pool: {}", connection2);
    session = connection2.createSession(false, Session.AUTO_ACKNOWLEDGE);
    connection2.close();
    pooledConnFact.stop();
}