@Override
public void print(String message) {
    log.
}