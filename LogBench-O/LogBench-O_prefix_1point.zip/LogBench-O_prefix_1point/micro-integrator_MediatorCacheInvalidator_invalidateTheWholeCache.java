@Override
public void invalidateTheWholeCache() {
    cacheManager.clean();
    log.
}