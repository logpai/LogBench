public void describeTo(InternalLog log) {
    // By default, log the full error. The intention is that sub classes can override this and
    // specify less extreme logging options.
    log.
}