@Override
public void doReportBug(BugInstance bugInstance) {
    if (includeCategories.size() > 0 && !includeCategories.contains(bugInstance.getCategoryAbbrev())) {
        return;
    }
    if (FbTestGlobalSettings.isRunningFromMaven()) {
        StringBuilder bugDetail = new StringBuilder();
        bugDetail.append("New bug ").append(bugInstance.getBugPattern().getType()).append(" ");
        if (bugInstance.getPrimaryClass() != null && bugInstance.getPrimaryMethod() != null && bugInstance.getPrimarySourceLineAnnotation() != null) {
            bugDetail.append("[").append(bugInstance.getPrimaryClass().getSimpleClassName()).append(".").append(bugInstance.getPrimaryMethod().getMethodName()).append("() at ").append(bugInstance.getPrimarySourceLineAnnotation().getStartLine()).append("]");
        } else if (bugInstance.getPrimaryClass() != null && bugInstance.getPrimaryField() != null && bugInstance.getPrimarySourceLineAnnotation() != null) {
            bugDetail.append("[").append(bugInstance.getPrimaryClass().getSimpleClassName()).append(".").append(bugInstance.getPrimaryField()).append(" at ").append(bugInstance.getPrimarySourceLineAnnotation().getStartLine()).append("]");
        }
        log.
    } else {
        StringBuilder bugDetail = new StringBuilder();
        bugDetail.append("\n------------------------------------------------------").append("\nNew Bug Instance: [" + ++bugInstanceCount + "]").append("\n  message=" + bugInstance.getMessage()).append("\n  bugType=" + bugInstance.getBugPattern().getType()).append("  priority=" + bugInstance.getPriorityString()).append("  category=" + bugInstance.getCategoryAbbrev());
        if (bugInstance.getPrimaryClass() != null) {
            bugDetail.append("\n  class=" + bugInstance.getPrimaryClass().getClassName());
        }
        if (bugInstance.getPrimaryMethod() != null) {
            bugDetail.append("  method=" + bugInstance.getPrimaryMethod().getMethodName());
        }
        if (bugInstance.getPrimaryField() != null) {
            bugDetail.append("  field=" + bugInstance.getPrimaryField().getFieldName());
        }
        if (bugInstance.getPrimarySourceLineAnnotation() != null) {
            bugDetail.append("  line=" + bugInstance.getPrimarySourceLineAnnotation().getStartLine());
        }
        List<String> bugs = getUnknownSources(bugInstance);
        if (bugs.size() > 0) {
            bugDetail.append("\n  sources=" + Arrays.asList(bugs));
        }
        bugDetail.append("\n------------------------------------------------------");
        log.info(bugDetail.toString());
        // bugCollection.add(bugInstance);
    }
}