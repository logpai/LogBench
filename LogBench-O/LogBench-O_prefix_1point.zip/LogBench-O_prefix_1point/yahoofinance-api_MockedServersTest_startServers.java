@BeforeClass
public static void startServers() {
    if (started) {
        return;
    }
    started = true;
    quotesServer = new MockWebServer();
    histQuotesServer = new MockWebServer();
    try {
        quotesServer.start();
        histQuotesServer.start();
    } catch (IOException e) {
        log.
    }
    String quotesBaseUrl = "http://localhost:" + quotesServer.getPort() + "/d/quotes.csv";
    String histQuotesBaseUrl = "http://localhost:" + histQuotesServer.getPort() + "/table.csv";
    System.setProperty("yahoofinance.baseurl.quotes", quotesBaseUrl);
    System.setProperty("yahoofinance.baseurl.histquotes", histQuotesBaseUrl);
    System.setProperty("yahoofinance.histquotes2.enabled", "false");
    System.setProperty("yahoofinance.quotesquery1v7.enabled", "false");
    final Dispatcher dispatcher = new YahooFinanceDispatcher();
    quotesServer.setDispatcher(dispatcher);
    histQuotesServer.setDispatcher(dispatcher);
}