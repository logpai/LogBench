/**
 * Get values of matching {@link ValidationResource} for provided {@link HttpServerRequest}
 *
 * @param validationResource the {@link ValidationResource} holding the configuration values
 * @param request the {@link HttpServerRequest} to lookup
 * @param log the {@link Logger}
 * @return a {@link Map} holding the corresponding configuration values or <code>null</code>
 */
public static Map<String, String> matchingValidationResourceEntry(ValidationResource validationResource, HttpServerRequest request, Logger log) {
    List<Map<String, String>> validationResources = validationResource.getResources();
    try {
        for (Map<String, String> entry : validationResources) {
            if (doesRequestValueMatch(request.method().name(), entry.get(ValidationResource.METHOD_PROPERTY)) && doesRequestValueMatch(request.uri(), entry.get(ValidationResource.URL_PROPERTY))) {
                return entry;
            }
        }
    } catch (PatternSyntaxException patternException) {
        log.
    }
    return null;
}