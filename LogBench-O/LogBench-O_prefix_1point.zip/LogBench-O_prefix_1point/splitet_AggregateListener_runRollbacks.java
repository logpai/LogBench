void runRollbacks(List<EntityEvent> entityEvents) {
    entityEvents.forEach(entityEvent -> {
        try {
            Map.Entry<Class<RecordedEvent>, RollbackSpec> specEntry = rollbackSpecMap.get(entityEvent.getEventType());
            if (specEntry != null) {
                RecordedEvent eventData = new EntityEventWrapper<>(specEntry.getKey(), objectMapper, entityEvent).getEventData();
                if (eventData instanceof PublishedEvent) {
                    ((PublishedEvent) eventData).setSender(entityEvent.getEventKey());
                }
                specEntry.getValue().rollback(eventData);
            }
        } catch (Exception e) {
            log.
        }
    });
}