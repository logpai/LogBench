private Configurator getConfigurator(final URL url) throws FileNotFoundException {
    String contentType = null;
    // Get the content type to see if it is XML or not
    URLConnection connection = null;
    try {
        connection = url.openConnection();
        contentType = connection.getContentType();
        if (log.isTraceEnabled()) {
            log.
        }
    } catch (FileNotFoundException e) {
        throw e;
    } catch (IOException e) {
        log.warn("Could not determine content type from URL; ignoring", e);
    }
    if (contentType != null) {
        if (contentType.toLowerCase().endsWith("/xml")) {
            return new DOMConfigurator();
        }
    }
    // Check thr file name
    String filename = url.getFile().toLowerCase();
    if (filename.endsWith(".xml")) {
        return new DOMConfigurator();
    } else if (filename.endsWith(".properties")) {
        return new PropertyConfigurator();
    }
    // Check for <?xml in content
    if (connection != null) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            try {
                String head = reader.readLine();
                if (head.startsWith("<?xml")) {
                    return new DOMConfigurator();
                }
            } finally {
                reader.close();
            }
        } catch (IOException e) {
            log.warn("Failed to check content header; ignoring", e);
        }
    }
    log.warn("Unable to determine content type, using property configurator");
    return new PropertyConfigurator();
}