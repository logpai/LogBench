@Test
public void testYouTubePublish() throws InterruptedException {
    log.
    String youtubeHost = "a.rtmp.youtube.com";
    int youtubePort = 1935;
    String youtubeApp = "live2";
    // System.getProperty("youtube.streamname");
    final String youtubePublishName = "dybx-y3ph-uqzx-30vx";
    log.info("youtubePublishName: {}", youtubePublishName);
    // if (youtubePublishName == null) {
    // log.info("You forgot to set a 'youtube.streamname' system property");
    // return;
    // }
    final RTMPClient client = new RTMPClient();
    client.setConnectionClosedHandler(new Runnable() {

        @Override
        public void run() {
            log.info("Test - exit");
        }
    });
    client.setExceptionHandler(new ClientExceptionHandler() {

        @Override
        public void handleException(Throwable throwable) {
            throwable.printStackTrace();
        }
    });
    client.setStreamEventDispatcher(new IEventDispatcher() {

        @Override
        public void dispatchEvent(IEvent event) {
            log.info("ClientStream.dispachEvent: {}", event);
        }
    });
    final INetStreamEventHandler netStreamEventHandler = new INetStreamEventHandler() {

        @Override
        public void onStreamEvent(Notify notify) {
            log.info("ClientStream.onStreamEvent: {}", notify);
        }
    };
    client.setStreamEventHandler(netStreamEventHandler);
    IPendingServiceCallback connectCallback = new IPendingServiceCallback() {

        @Override
        public void resultReceived(IPendingServiceCall call) {
            log.info("connectCallback");
            ObjectMap<?, ?> map = (ObjectMap<?, ?>) call.getResult();
            String code = (String) map.get("code");
            log.info("Response code: {}", code);
            if ("NetConnection.Connect.Rejected".equals(code)) {
                System.out.printf("Rejected: %s\n", map.get("description"));
                client.disconnect();
                finished.set(true);
            } else if ("NetConnection.Connect.Success".equals(code)) {
                client.createStream(new IPendingServiceCallback() {

                    @Override
                    public void resultReceived(IPendingServiceCall call) {
                        double streamId = (Double) call.getResult();
                        // live buffer 0.5s
                        @SuppressWarnings("unused")
                        RTMPConnection conn = (RTMPConnection) Red5.getConnectionLocal();
                        // conn.ping(new Ping(Ping.CLIENT_BUFFER, streamId, 500));
                        // client.play(streamId, youtubePublishName, -1, -1);
                        client.publish(streamId, youtubePublishName, "live", netStreamEventHandler);
                    }
                });
                // push data out for the publish
                // test();
            }
        }
    };
    // connect
    client.connect(youtubeHost, youtubePort, youtubeApp, connectCallback);
    Thread.currentThread().join(30000L);
    client.disconnect();
    log.info("Test - end");
}