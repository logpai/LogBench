@FXML
public void revealAndClose() {
    LOG.
    revealButtonState.set(ContentDisplay.LEFT);
    revealButtonDisabled.set(true);
    Task<Vault> revealTask = vaultService.createRevealTask(vault);
    revealTask.setOnSucceeded(evt -> {
        revealButtonState.set(ContentDisplay.TEXT_ONLY);
        revealButtonDisabled.set(false);
        window.close();
    });
    revealTask.setOnFailed(evt -> {
        LOG.warn("Reveal failed.", revealTask.getException());
        revealButtonState.set(ContentDisplay.TEXT_ONLY);
        revealButtonDisabled.set(false);
    });
    executor.execute(revealTask);
    if (rememberChoiceCheckbox.isSelected()) {
        vault.getVaultSettings().actionAfterUnlock().setValue(WhenUnlocked.REVEAL);
    }
}