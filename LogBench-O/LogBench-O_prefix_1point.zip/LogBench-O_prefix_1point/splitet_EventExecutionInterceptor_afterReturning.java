/*    @Before("this(EventHandler+) && execution(* execute(..)) && args(object)")
    public void before(JoinPoint jp, Object object) throws Throwable {
        String commandContext = object == null ? jp.getTarget().getClass().getSimpleName() : object.getClass().getSimpleName();
        operationContext.setCommandContext(commandContext);
        log.
    }*/
@AfterReturning(value = "this(io.splitet.core.api.EventHandler+) && execution(* execute(..))", returning = "retVal")
public void afterReturning(Object retVal) throws Throwable {
    log.debug("AfterReturning:" + (retVal == null ? "" : retVal.toString()));
    operationContext.clearCommandContext();
    userContext.clearUserContext();
}