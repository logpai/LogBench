private PingCallbackResponse _exec() {
    try {
        // Prepare request parameters
        // clientRequest.setHttpMethod(getHttpMethod());
        Builder clientRequest = webTarget.request();
        applyCookies(clientRequest);
        clientRequest.header("Content-Type", getRequest().getContentType());
        if (StringUtils.isNotBlank(getRequest().getClientNotificationToken())) {
            clientRequest.header("Authorization", "Bearer " + getRequest().getClientNotificationToken());
        }
        JSONObject requestBody = getRequest().getJSONParameters();
        // Call REST Service and handle response
        clientResponse = clientRequest.buildPost(Entity.json(requestBody.toString(4))).invoke();
        setResponse(new PingCallbackResponse(clientResponse));
    } catch (Exception e) {
        LOG.
    } finally {
        closeConnection();
    }
    return getResponse();
}