protected void handleException(String msg, Exception e) {
    log.
    throw new SynapseException(msg, e);
}