/**
 * Clear all existing constraints. This should be used when the constraint configuration resource
 * was removed.
 */
void clearConstraints() {
    log.
    this.constraints.clear();
}