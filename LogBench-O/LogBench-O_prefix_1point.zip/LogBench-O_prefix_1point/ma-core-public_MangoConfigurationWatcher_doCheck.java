private synchronized void doCheck() {
    try {
        WatchKey key = watchService.poll();
        if (key != null) {
            Path path = mangoProperties.getEnvPropertiesPath();
            for (WatchEvent<?> event : key.pollEvents()) {
                if (event.kind() == StandardWatchEventKinds.OVERFLOW) {
                    continue;
                }
                Path eventPath = (Path) event.context();
                if (eventPath.equals(path.getFileName())) {
                    executorService.execute(this::reloadAndFireEvent);
                    break;
                }
            }
            key.reset();
        }
    } catch (Exception e) {
        log.
    }
}