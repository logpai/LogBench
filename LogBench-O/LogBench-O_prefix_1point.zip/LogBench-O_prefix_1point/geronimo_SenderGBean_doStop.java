public void doStop() throws Exception {
    log.
}