private void handleException(String msg, Exception e, MessageContext msgContext) {
    LOG.
    if (msgContext.getServiceLog() != null) {
        msgContext.getServiceLog().error(msg, e);
    }
    throw new SynapseException(msg, e);
}