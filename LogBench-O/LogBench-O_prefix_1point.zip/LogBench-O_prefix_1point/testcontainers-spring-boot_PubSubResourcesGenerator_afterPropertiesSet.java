@Override
public void afterPropertiesSet() {
    log.
    topicAndSubscriptions.forEach(this::createTopicAndSubscription);
    log.info("Creating topics and subscriptions created.");
}