public void onFailure(IOException e) {
    if (!shuttingDown.get()) {
        LOG.
        try {
            stop();
        } catch (Exception ignore) {
        }
    }
}