/**
 * @throws CIFSException
 */
@Override
protected void doCloseInternal() throws CIFSException {
    try {
        @SuppressWarnings("resource")
        SmbTreeHandleImpl th = getTreeHandle();
        if (this.response != null) {
            th.send(new SmbComFindClose2(th.getConfig(), this.response.getSid()), new SmbComBlankResponse(th.getConfig()));
        }
    } catch (SmbException se) {
        log.
    }
}