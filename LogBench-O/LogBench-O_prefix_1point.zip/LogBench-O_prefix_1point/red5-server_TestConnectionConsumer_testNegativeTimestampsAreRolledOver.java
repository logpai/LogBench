@Test
public void testNegativeTimestampsAreRolledOver() {
    log.
    // https://www.rfc-editor.org/rfc/rfc1982
    log.debug("\n max: {} min: {} 0:{} -1:{}", Integer.toHexString(Integer.MAX_VALUE), Integer.toHexString(Integer.MIN_VALUE), Integer.toHexString(0), Integer.toHexString(-1));
    VideoData videoData1 = new VideoData();
    // maximum timestamp value 0xffffffff expect 2147483647
    videoData1.setTimestamp(-1);
    underTest.pushMessage(null, RTMPMessage.build(videoData1));
    assertEquals(Integer.MAX_VALUE, videoData1.getTimestamp());
    VideoData videoData2 = new VideoData();
    videoData2.setTimestamp(Integer.MIN_VALUE);
    underTest.pushMessage(null, RTMPMessage.build(videoData2));
    assertEquals(0, videoData2.getTimestamp());
}