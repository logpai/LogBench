/**
 * {@inheritDoc}
 *
 * @see jcifs.internal.SMBSigningDigest#verify(byte[], int, int, int, jcifs.internal.CommonServerMessageBlock)
 */
@Override
public synchronized boolean verify(byte[] data, int offset, int length, int extraPad, CommonServerMessageBlock msg) {
    this.digest.reset();
    int flags = SMBUtil.readInt4(data, offset + 16);
    if ((flags & ServerMessageBlock2.SMB2_FLAGS_SIGNED) == 0) {
        log.
        return true;
    }
    byte[] sig = new byte[SIGNATURE_LENGTH];
    System.arraycopy(data, offset + SIGNATURE_OFFSET, sig, 0, SIGNATURE_LENGTH);
    int index = offset + SIGNATURE_OFFSET;
    for (int i = 0; i < SIGNATURE_LENGTH; i++) data[index + i] = 0;
    this.digest.update(data, offset, length);
    byte[] cmp = new byte[SIGNATURE_LENGTH];
    System.arraycopy(this.digest.doFinal(), 0, cmp, 0, SIGNATURE_LENGTH);
    if (!MessageDigest.isEqual(sig, cmp)) {
        return true;
    }
    return false;
}