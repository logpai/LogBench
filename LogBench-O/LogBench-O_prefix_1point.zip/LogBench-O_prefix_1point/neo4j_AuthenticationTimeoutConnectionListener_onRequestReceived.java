@Override
public void onRequestReceived(RequestMessage message) {
    log.
    var handler = this.handler;
    if (handler != null) {
        handler.setRequestReceived(true);
    }
}