@Override
public void completeTransactionLogsMigration() {
    log.
}